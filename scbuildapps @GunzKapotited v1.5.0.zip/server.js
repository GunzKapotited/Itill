// server.js - LENGKAP DENGAN SEMUA KONFIGURASI LANGSUNG DI DALAM
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const FormData = require("form-data");
const { execSync } = require("child_process");

// KONFIGURASI LENGKAP - ISI SEMUA DI SINI

// TOKEN GITHUB - GANTI DENGAN TOKEN KAMU
const GITHUB_TOKEN = "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";

// REPO GITHUB - GANTI DENGAN REPO KAMU
const REPO_OWNER = "GunzKapotited";
const REPO_NAME = "Buildapp";

// WORKFLOW ID - NAMA FILE WORKFLOW DI .github/workflows/
const WORKFLOW_ID = "build.yml";
const WEB2APK_WORKFLOW_ID = "web2apk.yml";

// KONFIGURASI LAINNYA
const BUILD_TIMEOUT_MS = 600000; // 10 menit
const POLL_INTERVAL_MS = 5000; // 5 detik

// END KONFIGURASI

// SLEEP
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// VALIDASI TOKEN
if (!GITHUB_TOKEN || GITHUB_TOKEN === "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") {
  console.error("ERROR: GITHUB_TOKEN belum diisi!");
  console.error("Edit file server.js dan isi GITHUB_TOKEN dengan token GitHub kamu.");
  console.error("Bot akan tetap jalan tapi fungsi build TIDAK akan bekerja!");
}

if (REPO_OWNER === "username-anda" || REPO_NAME === "nama-repo-anda") {
  console.warn("PERINGATAN: REPO_OWNER atau REPO_NAME belum diisi!");
  console.warn("Edit file server.js dan isi dengan repo GitHub kamu.");
}

// GITHUB API
const GITHUB_API = "https://api.github.com";

const axiosGit = axios.create({
  baseURL: GITHUB_API,
  headers: {
    Authorization: `Bearer ${GITHUB_TOKEN}`,
    Accept: "application/vnd.github.v3+json",
  },
});

function repoPath(...segments) {
  return `/repos/${REPO_OWNER}/${REPO_NAME}/${segments.join("/")}`;
}

// CREATE RELEASE
async function createReleaseOnly(tag) {
  try {
    const response = await axiosGit.post(repoPath("releases"), {
      tag_name: tag,
      name: `Build ${tag}`,
      draft: false,
      prerelease: false,
      generate_release_notes: false,
    });
    return {
      releaseId: response.data.id,
      uploadUrl: response.data.upload_url.replace("{?name,label}", ""),
      htmlUrl: response.data.html_url,
    };
  } catch (error) {
    console.error("Error creating release:", error.response?.data || error.message);
    throw new Error(`Gagal membuat release: ${error.response?.data?.message || error.message}`);
  }
}

// UPLOAD ASSET
async function uploadAssetFile(uploadUrl, filePath, fileName, contentType) {
  try {
    const fileData = fs.readFileSync(filePath);
    const fileSize = fs.statSync(filePath).size;

    const response = await axios({
      method: "post",
      url: uploadUrl,
      headers: {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        "Content-Type": contentType || "application/zip",
        "Content-Length": fileSize,
      },
      data: fileData,
      params: { name: fileName },
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
    });

    return response.data.browser_download_url;
  } catch (error) {
    console.error("Error uploading asset:", error.response?.data || error.message);
    throw new Error(`Gagal upload asset: ${error.response?.data?.message || error.message}`);
  }
}

// UPLOAD ZIP TO RELEASE
async function uploadZipToRelease(zipPath, originalFileName, tag) {
  try {
    const { releaseId, uploadUrl, htmlUrl } = await createReleaseOnly(tag);

    let fileName = originalFileName;
    if (!fileName.endsWith(".zip")) {
      const base = path.basename(originalFileName, path.extname(originalFileName));
      fileName = `${base}.zip`;
    }

    const assetUrl = await uploadAssetFile(uploadUrl, zipPath, fileName, "application/zip");

    return {
      releaseId,
      uploadUrl,
      htmlUrl,
      assetUrl,
      browserUrl: htmlUrl,
    };
  } catch (error) {
    console.error("Error uploading zip to release:", error);
    throw error;
  }
}

// DELETE RELEASE
async function deleteRelease(releaseId) {
  if (!releaseId) return;
  try {
    await axiosGit.delete(repoPath(`releases/${releaseId}`));
    console.log(`Release ${releaseId} deleted`);
  } catch (error) {
    console.error(`Error deleting release ${releaseId}:`, error.response?.data || error.message);
  }
}

// TRIGGER WORKFLOW
async function triggerWorkflow(browserUrl, tag, buildType) {
  try {
    const response = await axiosGit.post(
      repoPath(`actions/workflows/${WORKFLOW_ID}/dispatches`),
      {
        ref: "main",
        inputs: {
          release_url: browserUrl,
          tag: tag,
          build_type: buildType || "release",
        },
      }
    );

    const location = response.headers.location;
    if (location) {
      const runIdMatch = location.match(/\/actions\/runs\/(\d+)/);
      if (runIdMatch) {
        return parseInt(runIdMatch[1]);
      }
    }

    const runs = await getWorkflowRuns(WORKFLOW_ID, 1);
    if (runs.length > 0) {
      return runs[0].id;
    }

    throw new Error("Gagal mendapatkan run ID");
  } catch (error) {
    console.error("Error triggering workflow:", error.response?.data || error.message);
    throw new Error(`Gagal trigger workflow: ${error.response?.data?.message || error.message}`);
  }
}

// TRIGGER WEB2APK WORKFLOW
async function triggerWeb2ApkWorkflow(webUrl, appName, iconUrl) {
  try {
    const response = await axiosGit.post(
      repoPath(`actions/workflows/${WEB2APK_WORKFLOW_ID}/dispatches`),
      {
        ref: "main",
        inputs: {
          web_url: webUrl,
          app_name: appName,
          icon_url: iconUrl,
        },
      }
    );

    const location = response.headers.location;
    if (location) {
      const runIdMatch = location.match(/\/actions\/runs\/(\d+)/);
      if (runIdMatch) {
        return parseInt(runIdMatch[1]);
      }
    }

    const runs = await getWorkflowRuns(WEB2APK_WORKFLOW_ID, 1);
    if (runs.length > 0) {
      return runs[0].id;
    }

    throw new Error("Gagal mendapatkan run ID");
  } catch (error) {
    console.error("Error triggering web2apk workflow:", error.response?.data || error.message);
    throw new Error(`Gagal trigger web2apk: ${error.response?.data?.message || error.message}`);
  }
}

// GET WORKFLOW RUNS
async function getWorkflowRuns(workflowId, limit = 5) {
  try {
    const response = await axiosGit.get(
      repoPath(`actions/workflows/${workflowId}/runs`),
      { params: { per_page: limit } }
    );
    return response.data.workflow_runs || [];
  } catch (error) {
    console.error("Error getting workflow runs:", error.response?.data || error.message);
    return [];
  }
}

// GET RUN STATUS
async function getRunStatus(runId) {
  try {
    const response = await axiosGit.get(repoPath(`actions/runs/${runId}`));
    const run = response.data;
    return {
      id: run.id,
      status: run.status,
      conclusion: run.conclusion,
      htmlUrl: run.html_url,
      durationSec: run.updated_at && run.created_at
        ? Math.floor((new Date(run.updated_at) - new Date(run.created_at)) / 1000)
        : 0,
      jobsUrl: run.jobs_url,
    };
  } catch (error) {
    console.error("Error getting run status:", error.response?.data || error.message);
    throw new Error(`Gagal dapat status run: ${error.response?.data?.message || error.message}`);
  }
}

// GET ARTIFACTS
async function getArtifacts(runId) {
  try {
    const response = await axiosGit.get(repoPath(`actions/runs/${runId}/artifacts`));
    return response.data.artifacts || [];
  } catch (error) {
    console.error("Error getting artifacts:", error.response?.data || error.message);
    return [];
  }
}

// DOWNLOAD ARTIFACT ZIP
async function downloadArtifactZip(artifactId, outputPath) {
  try {
    const response = await axiosGit.get(
      repoPath(`actions/artifacts/${artifactId}/zip`),
      { responseType: "arraybuffer" }
    );
    fs.writeFileSync(outputPath, response.data);
    return outputPath;
  } catch (error) {
    console.error("Error downloading artifact:", error.response?.data || error.message);
    throw new Error(`Gagal download artifact: ${error.response?.data?.message || error.message}`);
  }
}

// GET FAILED STEP LOG
async function getFailedStepLog(runId) {
  try {
    const jobsResponse = await axiosGit.get(repoPath(`actions/runs/${runId}/jobs`));
    const jobs = jobsResponse.data.jobs || [];

    const failedJob = jobs.find(j => j.conclusion === "failure");
    if (!failedJob) {
      return null;
    }

    const steps = failedJob.steps || [];
    const failedStep = steps.find(s => s.conclusion === "failure");
    if (!failedStep) {
      return null;
    }

    const logResponse = await axiosGit.get(
      repoPath(`actions/jobs/${failedJob.id}/logs`),
      { responseType: "text" }
    );

    const logLines = logResponse.data.split("\n");
    const errorLines = [];

    let inFailedStep = false;
    let stepName = failedStep.name || "Unknown step";

    for (const line of logLines) {
      if (line.includes(`##[group]${stepName}`) || line.includes(`##[group]${failedStep.name}`)) {
        inFailedStep = true;
        continue;
      }
      if (line.includes("##[endgroup]")) {
        inFailedStep = false;
        continue;
      }
      if (inFailedStep && (line.includes("error") || line.includes("Error") || line.includes("ERROR") || line.includes("failed") || line.includes("Failed"))) {
        errorLines.push(line);
      }
    }

    if (errorLines.length === 0) {
      const allLines = logResponse.data.split("\n");
      const start = Math.max(0, allLines.length - 20);
      return {
        stepName: stepName,
        errorLines: allLines.slice(start),
      };
    }

    return {
      stepName: stepName,
      errorLines: errorLines.slice(0, 50),
    };
  } catch (error) {
    console.error("Error getting failed step log:", error.message);
    return null;
  }
}

// PUBLISH RELEASE
async function publishRelease(releaseId) {
  try {
    const response = await axiosGit.patch(repoPath(`releases/${releaseId}`), {
      draft: false,
    });
    return response.data.html_url;
  } catch (error) {
    console.error("Error publishing release:", error.response?.data || error.message);
    throw new Error(`Gagal publish release: ${error.response?.data?.message || error.message}`);
  }
}

// GET RELEASE BY TAG
async function getReleaseByTag(tag) {
  try {
    const response = await axiosGit.get(repoPath(`releases/tags/${tag}`));
    return response.data;
  } catch (error) {
    if (error.response?.status === 404) {
      return null;
    }
    throw error;
  }
}

// LIST RELEASES
async function listReleases(page = 1, perPage = 30) {
  try {
    const response = await axiosGit.get(repoPath("releases"), {
      params: { page, per_page: perPage },
    });
    return response.data;
  } catch (error) {
    console.error("Error listing releases:", error.response?.data || error.message);
    return [];
  }
}

// DELETE ARTIFACT
async function deleteArtifact(artifactId) {
  try {
    await axiosGit.delete(repoPath(`actions/artifacts/${artifactId}`));
    return true;
  } catch (error) {
    console.error("Error deleting artifact:", error.response?.data || error.message);
    return false;
  }
}

// CLEANUP OLD RELEASES
async function cleanupOldReleases(keepCount = 50) {
  try {
    const releases = await listReleases(1, 100);
    if (releases.length <= keepCount) return;

    const sorted = releases.sort((a, b) => 
      new Date(a.created_at) - new Date(b.created_at)
    );

    const toDelete = sorted.slice(0, releases.length - keepCount);
    for (const release of toDelete) {
      if (release.draft) continue;
      await deleteRelease(release.id);
      console.log(`Deleted old release: ${release.tag_name}`);
    }
  } catch (error) {
    console.error("Error cleaning up releases:", error.message);
  }
}

// TEST CONNECTION
async function testGitHubConnection() {
  try {
    const response = await axiosGit.get("/rate_limit");
    console.log("GitHub API connected");
    console.log(`   Rate limit remaining: ${response.data.resources.core.remaining}`);
    console.log(`   Repo: ${REPO_OWNER}/${REPO_NAME}`);
    return true;
  } catch (error) {
    console.error("GitHub API connection failed:", error.response?.data?.message || error.message);
    return false;
  }
}

// EKSPOR SEMUA FUNGSI

module.exports = {
  // Upload
  uploadZipToRelease,
  uploadAssetFile,
  
  // Release
  createReleaseOnly,
  deleteRelease,
  publishRelease,
  getReleaseByTag,
  listReleases,
  cleanupOldReleases,
  
  // Workflow
  triggerWorkflow,
  triggerWeb2ApkWorkflow,
  getWorkflowRuns,
  getRunStatus,
  
  // Artifacts
  getArtifacts,
  downloadArtifactZip,
  deleteArtifact,
  
  // Logs
  getFailedStepLog,
  
  // Utils
  testGitHubConnection,
  sleep,
  
  // Konfigurasi (biar bisa diakses dari luar)
  GITHUB_TOKEN,
  REPO_OWNER,
  REPO_NAME,
  WORKFLOW_ID,
  WEB2APK_WORKFLOW_ID,
  BUILD_TIMEOUT_MS,
  POLL_INTERVAL_MS,
};

// AUTO RUN TEST SAAT DIJALANKAN

if (require.main === module) {
  console.log("Testing GitHub Connection...");
  testGitHubConnection().then(() => {
    console.log("\nServer.js siap digunakan!");
    console.log(`Repo: ${REPO_OWNER}/${REPO_NAME}`);
    console.log(`Workflow: ${WORKFLOW_ID}`);
    console.log(`Web2APK: ${WEB2APK_WORKFLOW_ID}`);
  });
}