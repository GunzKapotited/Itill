const axios = require("axios");
const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");

// ─── KONFIGURASI GITHUB ──────────────────────────────────────────────────────
// ⚠️ TOKEN BARU LU ⚠️
const GITHUB_TOKEN = "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";
const GITHUB_REPO = "GunzKapotited/Buildapp";
const GITHUB_OWNER = "GunzKapotited";
const GITHUB_REPO_NAME = "Buildapp";

const headers = {
  Authorization: `token ${GITHUB_TOKEN}`,
  Accept: "application/vnd.github.v3+json",
};

// ─── SLEEP ────────────────────────────────────────────────────────────────────
async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ─── CREATE RELEASE ──────────────────────────────────────────────────────────
async function createReleaseOnly(tag) {
  try {
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/releases`;
    const payload = {
      tag_name: tag,
      name: tag,
      draft: false,
      prerelease: false,
    };
    const response = await axios.post(url, payload, { headers });
    return {
      releaseId: response.data.id,
      uploadUrl: response.data.upload_url,
    };
  } catch (error) {
    console.error("[Server] createReleaseOnly error:", error.response?.data || error.message);
    throw new Error(`Gagal membuat release: ${error.response?.data?.message || error.message}`);
  }
}

// ─── UPLOAD ASSET ────────────────────────────────────────────────────────────
async function uploadAssetFile(uploadUrl, filePath, name, contentType) {
  try {
    const data = fs.readFileSync(filePath);
    const url = uploadUrl.replace("{?name,label}", `?name=${encodeURIComponent(name)}`);
    await axios.post(url, data, {
      headers: {
        ...headers,
        "Content-Type": contentType || "application/octet-stream",
        "Content-Length": data.length,
      },
    });
    console.log(`[Server] Uploaded asset: ${name}`);
  } catch (error) {
    console.error("[Server] uploadAssetFile error:", error.response?.data || error.message);
    throw new Error(`Gagal upload asset: ${error.response?.data?.message || error.message}`);
  }
}

// ─── PUBLISH RELEASE ─────────────────────────────────────────────────────────
async function publishRelease(releaseId) {
  try {
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/releases/${releaseId}`;
    const response = await axios.patch(url, { draft: false }, { headers });
    const assets = response.data.assets || [];
    const iconAsset = assets.find(a => a.name === "icon.png");
    return iconAsset ? iconAsset.browser_download_url : null;
  } catch (error) {
    console.error("[Server] publishRelease error:", error.response?.data || error.message);
    return null;
  }
}

// ─── UPLOAD ZIP TO RELEASE ──────────────────────────────────────────────────
async function uploadZipToRelease(zipPath, fileName, tag) {
  try {
    const { releaseId, uploadUrl } = await createReleaseOnly(tag);
    await uploadAssetFile(uploadUrl, zipPath, fileName, "application/zip");
    return {
      releaseId,
      browserUrl: `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/releases/tag/${tag}`,
    };
  } catch (error) {
    console.error("[Server] uploadZipToRelease error:", error);
    throw error;
  }
}

// ─── DELETE RELEASE ──────────────────────────────────────────────────────────
async function deleteRelease(releaseId) {
  try {
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/releases/${releaseId}`;
    await axios.delete(url, { headers });
    console.log(`[Server] Deleted release: ${releaseId}`);
  } catch (error) {
    console.warn("[Server] deleteRelease error:", error.response?.data || error.message);
  }
}

// ─── TRIGGER WORKFLOW ────────────────────────────────────────────────────────
async function triggerWorkflow(browserUrl, tag, buildType) {
  const workflowId = buildType === "debug" ? "debug-build.yml" : "release-build.yml";
  
  try {
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/actions/workflows/${workflowId}/dispatches`;
    const payload = {
      ref: "main",
      inputs: {
        tag: tag,
        build_type: buildType || "release",
      },
    };
    
    await axios.post(url, payload, { headers });
    console.log(`[Server] Triggered workflow: ${workflowId} with tag: ${tag}`);

    for (let i = 0; i < 60; i++) {
      await sleep(3000);
      const runsUrl = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/actions/runs`;
      const response = await axios.get(runsUrl, { headers });
      const runs = response.data.workflow_runs || [];
      
      const found = runs
        .filter(r => r.head_branch === "main" && r.status === "queued")
        .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0];
      
      if (found) {
        console.log(`[Server] Found workflow run: ${found.id}`);
        return found.id;
      }
    }
    
    throw new Error("Workflow run tidak muncul setelah 180 detik. Cek GitHub Actions repo kamu.");
  } catch (error) {
    console.error("[Server] triggerWorkflow error:", error.response?.data || error.message);
    throw new Error(`Gagal trigger workflow: ${error.response?.data?.message || error.message}`);
  }
}

// ─── GET RUN STATUS ──────────────────────────────────────────────────────────
async function getRunStatus(runId) {
  try {
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/actions/runs/${runId}`;
    const response = await axios.get(url, { headers });
    const data = response.data;
    
    return {
      status: data.status || "unknown",
      conclusion: data.conclusion || null,
      durationSec: data.updated_at && data.created_at 
        ? Math.floor((new Date(data.updated_at) - new Date(data.created_at)) / 1000)
        : 0,
    };
  } catch (error) {
    console.error("[Server] getRunStatus error:", error.response?.data || error.message);
    return { status: "unknown", conclusion: null, durationSec: 0 };
  }
}

// ─── GET ARTIFACTS ────────────────────────────────────────────────────────────
async function getArtifacts(runId) {
  try {
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/actions/runs/${runId}/artifacts`;
    const response = await axios.get(url, { headers });
    return response.data.artifacts || [];
  } catch (error) {
    console.error("[Server] getArtifacts error:", error.response?.data || error.message);
    return [];
  }
}

// ─── DOWNLOAD ARTIFACT ZIP ──────────────────────────────────────────────────
async function downloadArtifactZip(artifactId, destPath) {
  try {
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/actions/artifacts/${artifactId}/zip`;
    const response = await axios.get(url, {
      headers,
      responseType: "arraybuffer",
    });
    fs.writeFileSync(destPath, response.data);
    console.log(`[Server] Downloaded artifact to: ${destPath}`);
  } catch (error) {
    console.error("[Server] downloadArtifactZip error:", error.response?.data || error.message);
    throw new Error(`Gagal download artifact: ${error.response?.data?.message || error.message}`);
  }
}

// ─── GET FAILED STEP LOG ────────────────────────────────────────────────────
async function getFailedStepLog(runId) {
  try {
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/actions/runs/${runId}/jobs`;
    const response = await axios.get(url, { headers });
    const jobs = response.data.jobs || [];
    const failedJob = jobs.find(j => j.conclusion === "failure");
    
    if (failedJob) {
      const logUrl = failedJob.log_url;
      if (logUrl) {
        try {
          const logResponse = await axios.get(logUrl, { headers });
          const logText = logResponse.data;
          const lines = logText.split("\n").filter(l => 
            l.includes("error") || 
            l.includes("Error") || 
            l.includes("FAILED") ||
            l.includes("failed") ||
            l.includes("FAILURE")
          );
          return {
            stepName: failedJob.name || "Unknown Step",
            errorLines: lines.slice(0, 30),
          };
        } catch (logError) {
          console.warn("[Server] Failed to get log:", logError.message);
        }
      }
      return { stepName: failedJob.name || "Unknown Step", errorLines: ["Gagal mengambil log"] };
    }
    return null;
  } catch (error) {
    console.error("[Server] getFailedStepLog error:", error.response?.data || error.message);
    return null;
  }
}

// ─── TRIGGER WEB2APK WORKFLOW ──────────────────────────────────────────────
async function triggerWeb2ApkWorkflow(url, appName, iconUrl) {
  const workflowId = "web2apk.yml";
  
  try {
    const apiUrl = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/actions/workflows/${workflowId}/dispatches`;
    const payload = {
      ref: "main",
      inputs: {
        url: url,
        app_name: appName,
        icon_url: iconUrl || "https://example.com/icon.png",
      },
    };
    
    await axios.post(apiUrl, payload, { headers });
    console.log(`[Server] Triggered web2apk workflow for: ${appName}`);

    for (let i = 0; i < 60; i++) {
      await sleep(3000);
      const runsUrl = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO_NAME}/actions/runs`;
      const response = await axios.get(runsUrl, { headers });
      const runs = response.data.workflow_runs || [];
      
      const found = runs
        .filter(r => r.head_branch === "main" && r.status === "queued")
        .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))[0];
      
      if (found) {
        console.log(`[Server] Found web2apk workflow run: ${found.id}`);
        return found.id;
      }
    }
    
    throw new Error("Web2APK workflow tidak muncul setelah 180 detik.");
  } catch (error) {
    console.error("[Server] triggerWeb2ApkWorkflow error:", error.response?.data || error.message);
    throw new Error(`Gagal trigger Web2APK: ${error.response?.data?.message || error.message}`);
  }
}

// ─── EXPORT ──────────────────────────────────────────────────────────────────
module.exports = {
  uploadZipToRelease,
  deleteRelease,
  triggerWorkflow,
  getRunStatus,
  getArtifacts,
  downloadArtifactZip,
  getFailedStepLog,
  sleep,
  createReleaseOnly,
  uploadAssetFile,
  triggerWeb2ApkWorkflow,
  publishRelease,
};