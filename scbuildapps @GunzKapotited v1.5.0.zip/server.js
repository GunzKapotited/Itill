// server.js - FIXED
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const FormData = require("form-data");
const { execSync } = require("child_process");

// KONFIGURASI
const GITHUB_TOKEN = "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";
const REPO_OWNER = "GunzKapotited";
const REPO_NAME = "Buildapp";
const WORKFLOW_ID = "flutter-build.yml";
const WEB2APK_WORKFLOW_ID = "web2apk-build.yml";
const BUILD_TIMEOUT_MS = 600000;
const POLL_INTERVAL_MS = 5000;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// VALIDASI - cek apakah token masih default
if (!GITHUB_TOKEN || GITHUB_TOKEN.startsWith("github_pat_")) {
  console.log("GITHUB_TOKEN sudah diisi");
} else {
  console.error("ERROR: GITHUB_TOKEN belum diisi");
  process.exit(1);
}

const GITHUB_API = "https://api.github.com";

const axiosGit = axios.create({
  baseURL: GITHUB_API,
  headers: {
    Authorization: `Bearer ${GITHUB_TOKEN}`,
    Accept: "application/vnd.github.v3+json",
  },
});

function repoPath(...segments) {
  return `/repos/${REPO_OWNER}/${REPO_NAME}/${segments.join("/")}`;
}

async function createReleaseOnly(tag) {
  try {
    const response = await axiosGit.post(repoPath("releases"), {
      tag_name: tag,
      name: `Build ${tag}`,
      draft: false,
      prerelease: false,
      generate_release_notes: false,
    });
    return {
      releaseId: response.data.id,
      uploadUrl: response.data.upload_url.replace("{?name,label}", ""),
      htmlUrl: response.data.html_url,
    };
  } catch (error) {
    console.error("Error creating release:", error.response?.data || error.message);
    if (error.response?.status === 401) {
      throw new Error("Token GitHub tidak valid. Periksa GITHUB_TOKEN di server.js");
    }
    if (error.response?.status === 404) {
      throw new Error(`Repo ${REPO_OWNER}/${REPO_NAME} tidak ditemukan. Periksa REPO_OWNER dan REPO_NAME`);
    }
    throw new Error(`Gagal membuat release: ${error.response?.data?.message || error.message}`);
  }
}

async function uploadAssetFile(uploadUrl, filePath, fileName, contentType) {
  try {
    const fileData = fs.readFileSync(filePath);
    const fileSize = fs.statSync(filePath).size;

    const response = await axios({
      method: "post",
      url: uploadUrl,
      headers: {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        "Content-Type": contentType || "application/zip",
        "Content-Length": fileSize,
      },
      data: fileData,
      params: { name: fileName },
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
    });

    return response.data.browser_download_url;
  } catch (error) {
    console.error("Error uploading asset:", error.response?.data || error.message);
    throw new Error(`Gagal upload asset: ${error.response?.data?.message || error.message}`);
  }
}

async function uploadZipToRelease(zipPath, originalFileName, tag) {
  try {
    if (!fs.existsSync(zipPath)) {
      throw new Error(`File ZIP tidak ditemukan: ${zipPath}`);
    }

    const { releaseId, uploadUrl, htmlUrl } = await createReleaseOnly(tag);

    let fileName = originalFileName;
    if (!fileName.endsWith(".zip")) {
      const base = path.basename(originalFileName, path.extname(originalFileName));
      fileName = `${base}.zip`;
    }

    const assetUrl = await uploadAssetFile(uploadUrl, zipPath, fileName, "application/zip");

    return {
      releaseId,
      uploadUrl,
      htmlUrl,
      assetUrl,
      browserUrl: htmlUrl,
    };
  } catch (error) {
    console.error("Error uploading zip to release:", error);
    throw error;
  }
}

async function deleteRelease(releaseId) {
  if (!releaseId) return;
  try {
    await axiosGit.delete(repoPath(`releases/${releaseId}`));
  } catch (error) {
    console.error(`Error deleting release ${releaseId}:`, error.response?.data || error.message);
  }
}

async function triggerWorkflow(browserUrl, tag, buildType) {
  try {
    const response = await axiosGit.post(
      repoPath(`actions/workflows/${WORKFLOW_ID}/dispatches`),
      {
        ref: "main",
        inputs: {
          release_url: browserUrl,
          tag: tag,
          build_type: buildType || "release",
        },
      }
    );

    const location = response.headers.location;
    if (location) {
      const runIdMatch = location.match(/\/actions\/runs\/(\d+)/);
      if (runIdMatch) {
        return parseInt(runIdMatch[1]);
      }
    }

    const runs = await getWorkflowRuns(WORKFLOW_ID, 1);
    if (runs.length > 0) {
      return runs[0].id;
    }

    throw new Error("Gagal mendapatkan run ID");
  } catch (error) {
    console.error("Error triggering workflow:", error.response?.data || error.message);
    throw new Error(`Gagal trigger workflow: ${error.response?.data?.message || error.message}`);
  }
}

async function triggerWeb2ApkWorkflow(webUrl, appName, iconUrl) {
  try {
    const response = await axiosGit.post(
      repoPath(`actions/workflows/${WEB2APK_WORKFLOW_ID}/dispatches`),
      {
        ref: "main",
        inputs: {
          web_url: webUrl,
          app_name: appName,
          icon_url: iconUrl,
        },
      }
    );

    const location = response.headers.location;
    if (location) {
      const runIdMatch = location.match(/\/actions\/runs\/(\d+)/);
      if (runIdMatch) {
        return parseInt(runIdMatch[1]);
      }
    }

    const runs = await getWorkflowRuns(WEB2APK_WORKFLOW_ID, 1);
    if (runs.length > 0) {
      return runs[0].id;
    }

    throw new Error("Gagal mendapatkan run ID");
  } catch (error) {
    console.error("Error triggering web2apk workflow:", error.response?.data || error.message);
    throw new Error(`Gagal trigger web2apk: ${error.response?.data?.message || error.message}`);
  }
}

async function getWorkflowRuns(workflowId, limit = 5) {
  try {
    const response = await axiosGit.get(
      repoPath(`actions/workflows/${workflowId}/runs`),
      { params: { per_page: limit } }
    );
    return response.data.workflow_runs || [];
  } catch (error) {
    console.error("Error getting workflow runs:", error.response?.data || error.message);
    return [];
  }
}

async function getRunStatus(runId) {
  try {
    const response = await axiosGit.get(repoPath(`actions/runs/${runId}`));
    const run = response.data;
    return {
      id: run.id,
      status: run.status,
      conclusion: run.conclusion,
      htmlUrl: run.html_url,
      durationSec: run.updated_at && run.created_at
        ? Math.floor((new Date(run.updated_at) - new Date(run.created_at)) / 1000)
        : 0,
      jobsUrl: run.jobs_url,
    };
  } catch (error) {
    console.error("Error getting run status:", error.response?.data || error.message);
    throw new Error(`Gagal dapat status run: ${error.response?.data?.message || error.message}`);
  }
}

async function getArtifacts(runId) {
  try {
    const response = await axiosGit.get(repoPath(`actions/runs/${runId}/artifacts`));
    return response.data.artifacts || [];
  } catch (error) {
    console.error("Error getting artifacts:", error.response?.data || error.message);
    return [];
  }
}

async function downloadArtifactZip(artifactId, outputPath) {
  try {
    const response = await axiosGit.get(
      repoPath(`actions/artifacts/${artifactId}/zip`),
      { responseType: "arraybuffer" }
    );
    fs.writeFileSync(outputPath, response.data);
    return outputPath;
  } catch (error) {
    console.error("Error downloading artifact:", error.response?.data || error.message);
    throw new Error(`Gagal download artifact: ${error.response?.data?.message || error.message}`);
  }
}

async function getFailedStepLog(runId) {
  try {
    const jobsResponse = await axiosGit.get(repoPath(`actions/runs/${runId}/jobs`));
    const jobs = jobsResponse.data.jobs || [];

    const failedJob = jobs.find(j => j.conclusion === "failure");
    if (!failedJob) {
      return null;
    }

    const steps = failedJob.steps || [];
    const failedStep = steps.find(s => s.conclusion === "failure");
    if (!failedStep) {
      return null;
    }

    const logResponse = await axiosGit.get(
      repoPath(`actions/jobs/${failedJob.id}/logs`),
      { responseType: "text" }
    );

    const logLines = logResponse.data.split("\n");
    const errorLines = [];

    let inFailedStep = false;
    let stepName = failedStep.name || "Unknown step";

    for (const line of logLines) {
      if (line.includes(`##[group]${stepName}`) || line.includes(`##[group]${failedStep.name}`)) {
        inFailedStep = true;
        continue;
      }
      if (line.includes("##[endgroup]")) {
        inFailedStep = false;
        continue;
      }
      if (inFailedStep && (line.includes("error") || line.includes("Error") || line.includes("ERROR") || line.includes("failed") || line.includes("Failed"))) {
        errorLines.push(line);
      }
    }

    if (errorLines.length === 0) {
      const allLines = logResponse.data.split("\n");
      const start = Math.max(0, allLines.length - 20);
      return {
        stepName: stepName,
        errorLines: allLines.slice(start),
      };
    }

    return {
      stepName: stepName,
      errorLines: errorLines.slice(0, 50),
    };
  } catch (error) {
    console.error("Error getting failed step log:", error.message);
    return null;
  }
}

async function publishRelease(releaseId) {
  try {
    const response = await axiosGit.patch(repoPath(`releases/${releaseId}`), {
      draft: false,
    });
    return response.data.html_url;
  } catch (error) {
    console.error("Error publishing release:", error.response?.data || error.message);
    throw new Error(`Gagal publish release: ${error.response?.data?.message || error.message}`);
  }
}

async function getReleaseByTag(tag) {
  try {
    const response = await axiosGit.get(repoPath(`releases/tags/${tag}`));
    return response.data;
  } catch (error) {
    if (error.response?.status === 404) {
      return null;
    }
    throw error;
  }
}

async function listReleases(page = 1, perPage = 30) {
  try {
    const response = await axiosGit.get(repoPath("releases"), {
      params: { page, per_page: perPage },
    });
    return response.data;
  } catch (error) {
    console.error("Error listing releases:", error.response?.data || error.message);
    return [];
  }
}

async function deleteArtifact(artifactId) {
  try {
    await axiosGit.delete(repoPath(`actions/artifacts/${artifactId}`));
    return true;
  } catch (error) {
    console.error("Error deleting artifact:", error.response?.data || error.message);
    return false;
  }
}

async function cleanupOldReleases(keepCount = 50) {
  try {
    const releases = await listReleases(1, 100);
    if (releases.length <= keepCount) return;

    const sorted = releases.sort((a, b) => 
      new Date(a.created_at) - new Date(b.created_at)
    );

    const toDelete = sorted.slice(0, releases.length - keepCount);
    for (const release of toDelete) {
      if (release.draft) continue;
      await deleteRelease(release.id);
    }
  } catch (error) {
    console.error("Error cleaning up releases:", error.message);
  }
}

async function testGitHubConnection() {
  try {
    const response = await axiosGit.get("/rate_limit");
    console.log("GitHub API connected");
    console.log(`Rate limit remaining: ${response.data.resources.core.remaining}`);
    console.log(`Repo: ${REPO_OWNER}/${REPO_NAME}`);
    return true;
  } catch (error) {
    console.error("GitHub API connection failed:", error.response?.data?.message || error.message);
    return false;
  }
}

async function testGitHubToken() {
  try {
    const response = await axios.get("https://api.github.com/user", {
      headers: {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        Accept: "application/vnd.github.v3+json",
      },
    });
    console.log(`Token valid. Login sebagai: ${response.data.login}`);
    
    const repoTest = await axios.get(
      `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}`,
      {
        headers: {
          Authorization: `Bearer ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github.v3+json",
        },
      }
    );
    console.log(`Akses ke repo ${REPO_OWNER}/${REPO_NAME} berhasil`);
    return true;
  } catch (error) {
    console.error("Token tidak valid atau tidak memiliki akses");
    console.error(`Error: ${error.response?.data?.message || error.message}`);
    if (error.response?.status === 401) {
      console.error("Status: 401 Unauthorized - Token salah atau expired");
    }
    if (error.response?.status === 404) {
      console.error("Status: 404 Not Found - Pastikan REPO_OWNER dan REPO_NAME benar");
    }
    return false;
  }
}

module.exports = {
  uploadZipToRelease,
  uploadAssetFile,
  createReleaseOnly,
  deleteRelease,
  publishRelease,
  getReleaseByTag,
  listReleases,
  cleanupOldReleases,
  triggerWorkflow,
  triggerWeb2ApkWorkflow,
  getWorkflowRuns,
  getRunStatus,
  getArtifacts,
  downloadArtifactZip,
  deleteArtifact,
  getFailedStepLog,
  testGitHubConnection,
  testGitHubToken,
  sleep,
  GITHUB_TOKEN,
  REPO_OWNER,
  REPO_NAME,
  WORKFLOW_ID,
  WEB2APK_WORKFLOW_ID,
  BUILD_TIMEOUT_MS,
  POLL_INTERVAL_MS,
};

if (require.main === module) {
  console.log("Testing GitHub Connection...");
  testGitHubToken().then((valid) => {
    if (valid) {
      console.log("Server.js siap digunakan");
      console.log(`Repo: ${REPO_OWNER}/${REPO_NAME}`);
      console.log(`Workflow: ${WORKFLOW_ID}`);
      console.log(`Web2APK: ${WEB2APK_WORKFLOW_ID}`);
    } else {
      console.log("Perbaiki konfigurasi di server.js sebelum menggunakan bot");
    }
  });
}