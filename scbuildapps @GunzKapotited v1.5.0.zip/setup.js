const { exec, execSync, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');
const axios = require('axios');
const AdmZip = require('adm-zip');

const TMP_DIR = './tmp';
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

console.log('🚀 AUTO SETUP BOT BUILD LOCAL');
console.log('====================================\n');

// ─── CEK OS ──────────────────────────────────────────────────────────────
const platform = os.platform();
console.log(`📌 OS: ${platform}`);

// ─── INSTALL FLUTTER ──────────────────────────────────────────────────────
async function installFlutter() {
  console.log('\n📦 Installing Flutter...');
  
  const flutterHome = path.join(os.homedir(), 'flutter');
  
  if (fs.existsSync(flutterHome)) {
    console.log('✅ Flutter already installed at:', flutterHome);
    return flutterHome;
  }

  try {
    if (platform === 'linux' || platform === 'darwin') {
      // Download Flutter
      const flutterUrl = platform === 'darwin' 
        ? 'https://storage.googleapis.com/flutter_infra_release/releases/stable/macos/flutter_macos_3.22.0-stable.zip'
        : 'https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.22.0-stable.zip';
      
      console.log(`📥 Downloading Flutter from: ${flutterUrl}`);
      
      const zipPath = path.join(TMP_DIR, 'flutter.zip');
      const response = await axios({
        method: 'get',
        url: flutterUrl,
        responseType: 'stream',
      });
      
      const writer = fs.createWriteStream(zipPath);
      response.data.pipe(writer);
      
      await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
      });
      
      console.log('📦 Extracting Flutter...');
      const zip = new AdmZip(zipPath);
      zip.extractAllTo(os.homedir(), true);
      
      fs.unlinkSync(zipPath);
      
      console.log('✅ Flutter installed at:', flutterHome);
      return flutterHome;
      
    } else {
      console.log('⚠️ Windows not supported for auto-install. Install Flutter manually.');
      console.log('   Download from: https://docs.flutter.dev/get-started/install/windows');
      return null;
    }
  } catch (error) {
    console.error('❌ Failed to install Flutter:', error.message);
    console.log('📌 Install Flutter manually: https://docs.flutter.dev/get-started/install');
    return null;
  }
}

// ─── INSTALL ANDROID SDK ──────────────────────────────────────────────────
async function installAndroidSdk() {
  console.log('\n📦 Installing Android SDK...');
  
  const androidHome = path.join(os.homedir(), 'Android', 'Sdk');
  
  if (fs.existsSync(androidHome)) {
    console.log('✅ Android SDK already installed at:', androidHome);
    return androidHome;
  }

  try {
    if (platform === 'linux') {
      // Download Command Line Tools
      const sdkUrl = 'https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip';
      const zipPath = path.join(TMP_DIR, 'sdk.zip');
      
      console.log(`📥 Downloading Android SDK from: ${sdkUrl}`);
      
      const response = await axios({
        method: 'get',
        url: sdkUrl,
        responseType: 'stream',
      });
      
      const writer = fs.createWriteStream(zipPath);
      response.data.pipe(writer);
      
      await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
      });
      
      console.log('📦 Extracting Android SDK...');
      const sdkDir = path.join(os.homedir(), 'Android');
      if (!fs.existsSync(sdkDir)) fs.mkdirSync(sdkDir, { recursive: true });
      
      const zip = new AdmZip(zipPath);
      const extractDir = path.join(sdkDir, 'cmdline-tools');
      if (!fs.existsSync(extractDir)) fs.mkdirSync(extractDir, { recursive: true });
      zip.extractAllTo(path.join(extractDir, 'latest'), true);
      
      fs.unlinkSync(zipPath);
      
      console.log('✅ Android SDK installed at:', androidHome);
      return androidHome;
      
    } else if (platform === 'darwin') {
      const sdkUrl = 'https://dl.google.com/android/repository/commandlinetools-mac-11076708_latest.zip';
      const zipPath = path.join(TMP_DIR, 'sdk.zip');
      
      console.log(`📥 Downloading Android SDK from: ${sdkUrl}`);
      
      const response = await axios({
        method: 'get',
        url: sdkUrl,
        responseType: 'stream',
      });
      
      const writer = fs.createWriteStream(zipPath);
      response.data.pipe(writer);
      
      await new Promise((resolve, reject) => {
        writer.on('finish', resolve);
        writer.on('error', reject);
      });
      
      console.log('📦 Extracting Android SDK...');
      const sdkDir = path.join(os.homedir(), 'Android');
      if (!fs.existsSync(sdkDir)) fs.mkdirSync(sdkDir, { recursive: true });
      
      const zip = new AdmZip(zipPath);
      const extractDir = path.join(sdkDir, 'cmdline-tools');
      if (!fs.existsSync(extractDir)) fs.mkdirSync(extractDir, { recursive: true });
      zip.extractAllTo(path.join(extractDir, 'latest'), true);
      
      fs.unlinkSync(zipPath);
      
      console.log('✅ Android SDK installed at:', androidHome);
      return androidHome;
      
    } else {
      console.log('⚠️ Windows not supported for auto-install. Install Android SDK manually.');
      console.log('   Download from: https://developer.android.com/studio#command-line-tools-only');
      return null;
    }
  } catch (error) {
    console.error('❌ Failed to install Android SDK:', error.message);
    console.log('📌 Install Android SDK manually: https://developer.android.com/studio#command-line-tools-only');
    return null;
  }
}

// ─── INSTALL SDK PLATFORMS ────────────────────────────────────────────────
async function installAndroidPlatforms(androidHome) {
  console.log('\n📦 Installing Android Platforms...');
  
  if (!androidHome) {
    console.log('⚠️ Android SDK not installed, skipping platforms');
    return;
  }

  try {
    const sdkmanager = platform === 'win32'
      ? path.join(androidHome, 'cmdline-tools', 'latest', 'bin', 'sdkmanager.bat')
      : path.join(androidHome, 'cmdline-tools', 'latest', 'bin', 'sdkmanager');
    
    if (!fs.existsSync(sdkmanager)) {
      console.log('⚠️ sdkmanager not found, skipping platforms');
      return;
    }

    const cmds = [
      `"${sdkmanager}" --sdk_root="${androidHome}" "platform-tools" "platforms;android-34" "build-tools;34.0.0"`,
      `"${sdkmanager}" --sdk_root="${androidHome}" "platforms;android-33" "build-tools;33.0.0"`,
    ];

    for (const cmd of cmds) {
      console.log(`📥 Running: ${cmd}`);
      try {
        execSync(cmd, { stdio: 'inherit', shell: true });
      } catch (e) {
        console.log('⚠️ Some packages already installed or error:', e.message);
      }
    }
    
    console.log('✅ Android Platforms installed!');
  } catch (error) {
    console.error('❌ Failed to install Android platforms:', error.message);
  }
}

// ─── SETUP ENVIRONMENT ────────────────────────────────────────────────────
function setupEnvironment(flutterHome, androidHome) {
  console.log('\n📝 Setting up environment variables...');
  
  const envFile = path.join(process.cwd(), '.env');
  let envContent = '';
  
  if (fs.existsSync(envFile)) {
    envContent = fs.readFileSync(envFile, 'utf-8');
  }
  
  if (flutterHome) {
    const flutterBin = path.join(flutterHome, 'bin');
    if (!envContent.includes('FLUTTER_ROOT')) {
      envContent += `\nFLUTTER_ROOT=${flutterHome}`;
      envContent += `\nPATH=${flutterBin}:$PATH`;
    }
  }
  
  if (androidHome) {
    if (!envContent.includes('ANDROID_HOME')) {
      envContent += `\nANDROID_HOME=${androidHome}`;
      envContent += `\nPATH=${path.join(androidHome, 'platform-tools')}:$PATH`;
      envContent += `\nPATH=${path.join(androidHome, 'cmdline-tools', 'latest', 'bin')}:$PATH`;
    }
  }
  
  fs.writeFileSync(envFile, envContent.trim());
  console.log('✅ Environment variables saved to .env');
}

// ─── VERIFY FLUTTER ──────────────────────────────────────────────────────
async function verifyFlutter() {
  console.log('\n🔍 Verifying Flutter installation...');
  
  try {
    // Coba panggil flutter dari PATH
    const flutterPath = process.env.FLUTTER_ROOT 
      ? path.join(process.env.FLUTTER_ROOT, 'bin', 'flutter')
      : 'flutter';
    
    const result = execSync(`"${flutterPath}" --version`, { 
      encoding: 'utf-8',
      shell: true,
      stdio: 'pipe',
    });
    
    const version = result.split('\n')[0] || 'Unknown';
    console.log('✅ Flutter version:', version);
    return true;
  } catch (error) {
    console.log('⚠️ Flutter not in PATH, trying to fix...');
    
    // Coba cari di home
    const flutterHome = path.join(os.homedir(), 'flutter');
    if (fs.existsSync(flutterHome)) {
      const flutterBin = path.join(flutterHome, 'bin', 'flutter');
      try {
        const result = execSync(`"${flutterBin}" --version`, { 
          encoding: 'utf-8',
          shell: true,
          stdio: 'pipe',
        });
        console.log('✅ Flutter found at:', flutterBin);
        console.log('✅ Flutter version:', result.split('\n')[0]);
        return true;
      } catch (e) {
        console.log('❌ Flutter not working:', e.message);
        return false;
      }
    }
    
    console.log('❌ Flutter not found!');
    return false;
  }
}

// ─── MAIN ──────────────────────────────────────────────────────────────────
async function main() {
  console.log('====================================');
  console.log('🔧 AUTO SETUP BOT BUILD LOCAL');
  console.log('====================================\n');
  
  // 1. Install Flutter
  const flutterHome = await installFlutter();
  
  // 2. Install Android SDK
  const androidHome = await installAndroidSdk();
  
  // 3. Install Android Platforms
  await installAndroidPlatforms(androidHome);
  
  // 4. Setup environment
  setupEnvironment(flutterHome, androidHome);
  
  // 5. Verify
  const verified = await verifyFlutter();
  
  console.log('\n====================================');
  if (verified && flutterHome) {
    console.log('✅ SETUP BERHASIL!');
    console.log(`📌 Flutter: ${flutterHome || 'Unknown'}`);
    console.log(`📌 Android SDK: ${androidHome || 'Unknown'}`);
    console.log('\n🚀 Jalankan bot dengan: npm start');
  } else {
    console.log('⚠️ SETUP GAGAL!');
    console.log('📌 Install Flutter manual: https://docs.flutter.dev/get-started/install');
    console.log('📌 Install Android SDK manual: https://developer.android.com/studio');
  }
  console.log('====================================');
}

main().catch(console.error);