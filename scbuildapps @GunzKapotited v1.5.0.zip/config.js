module.exports = {
  BOT_TOKEN: process.env.BOT_TOKEN || "8572881982:AAG_y7zsXZByeXa_KrKGiAv1LrBO-bVDbt0",
  BOT_NAME: process.env.BOT_NAME || "𝐁𝐎𝐓 𝐁𝐔𝐈𝐋𝐃 𝐆𝐔𝐍𝐙",
  BOT_VERSION: "𝟏.𝟓.𝟎",

  OWNER_ID: parseInt(process.env.OWNER_ID || "8212614573"),
  ADMIN_IDS: (process.env.ADMIN_IDS || "8212614573").split(",").map(id => parseInt(id.trim())),

  CHANNEL_USERNAME: process.env.CHANNEL_USERNAME || "@infobotbuildgunz",
  CHANNEL_USERNAME2: process.env.CHANNEL_USERNAME2 || "@gballpublic",
  CHANNEL_USERNAME3: process.env.CHANNEL_USERNAME3 || "@gballpublic",
 
  WELCOME_PHOTO: process.env.WELCOME_PHOTO || "https://files.catbox.moe/08r499.png",
  NEW_USER: process.env.NEW_USER || "https://files.catbox.moe/08r499.png",
  
  TMP_DIR: process.env.TMP_DIR || "./tmp",
  BUILD_TIMEOUT_MS: parseInt(process.env.BUILD_TIMEOUT_MS || "600000"),
  POLL_INTERVAL_MS: parseInt(process.env.POLL_INTERVAL_MS || "5000"),
  
  API_ID: parseInt(process.env.API_ID || "26433676"),
  API_HASH: process.env.API_HASH || "27a7326126594494a3bca73afc6c4295",
  
  WEB2APK_MAINTENANCE: process.env.WEB2APK_MAINTENANCE === "true" || false,
};